import java.util.*;
import java.io.File;
import java.io.PrintWriter;

public class ArtistMenu extends AdminMenu {

    private ArrayList<Artist> artists = new ArrayList<Artist>();

    public void readArtist() {
        try {
            Scanner infile = new Scanner(new File("Artist.txt"));

            while (infile.hasNextLine()) {
                String name = infile.nextLine();
                int age = Integer.parseInt(infile.nextLine());
                String specialty = infile.nextLine();
                String status = infile.nextLine();
                String priceRange = infile.nextLine();
                artists.add(new Artist(name, age, specialty, status, priceRange));
            }
            infile.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void updateArtist() {
        try {
            PrintWriter outfile = new PrintWriter("Artist.txt");

            for (Artist artist : artists) {
                outfile.println(artist.getName().toUpperCase() + "\n" + artist.getAge() + "\n"
                        + artist.getSpecialty().toUpperCase() + "\n" + artist.getStatus().toUpperCase() + "\n"
                        + artist.getPriceRange());
            }
            outfile.close();

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @Override
    public void viewInfo() {
        System.out.println("\t\tArtist List");
        System.out.println("_____________________________________________\n");
        for (int i = 0; i < artists.size(); i++) {
            System.out.println("\nArtist " + (i + 1));
            System.out.println("_____________________");
            System.out.println("Name: " + artists.get(i).getName());
            System.out.println("Age: " + artists.get(i).getAge());
            System.out.println("Specialty: " + artists.get(i).getSpecialty());
            System.out.println("Status: " + artists.get(i).getStatus());
            System.out.println("Price Range of Artwork: " + artists.get(i).getPriceRange());
        }
        System.out.println();
    }

    @Override
    public void addInfo() {
        System.out.println("\t\tArtist Registration");
        System.out.println("_____________________________________________");
        Scanner input = new Scanner(System.in);

        boolean exist = false;

        System.out.println("Enter '0' to back to the HOME PAGE");
        System.out.print("Enter Artist Name: ");
        String name = input.nextLine();
        
        if(name.contentEquals("0"))
        	exist = true;
        for (int i = 0; i < artists.size(); i++) {
            if (name.equalsIgnoreCase(artists.get(i).getName())) {
                exist = true;
            }
        }

        if (!exist) {
            int age = 0;
            do {
                try {
                    System.out.print("Enter Artist Age (OR age at deceased): ");
                    age = Integer.parseInt(input.nextLine());
                } catch (Exception ex) {
                    System.out.println("Artist age must larger than 0.");
                }
            } while (age <= 0);

            System.out.print("Enter Artist Specialty: ");
            String specialty = input.nextLine();

            String status;
            do {
                System.out.print("Enter Status (Alive/Deceased): ");
                status = input.nextLine();

                if (!status.equalsIgnoreCase("ALIVE") && !status.equalsIgnoreCase("Deceased")) {
                    System.out.println("\nArtist Status should be <ALIVE> or <DECEASED> only.\n");
                }
            } while (!status.equalsIgnoreCase("ALIVE") && !status.equalsIgnoreCase("Deceased"));

            boolean validRange = false;
            String priceRange = "0";
            double min = -1;
            double max = -1;
            do {
                do {
                    try {
                        System.out.print("Enter Artwork Minimum Price: ");
                        min = Double.parseDouble(input.nextLine());
                        System.out.print("Enter Artwork Maximum Price: ");
                        max = Double.parseDouble(input.nextLine());
                        priceRange = min + "-" + max;
                        validRange = true;
                    } catch (Exception ex) {
                        System.out.println("INVALID INPUT.");
                    }
                } while (!validRange);
            } while (min < 0 || max < 0 || max < min);

            artists.add(new Artist(name, age, specialty, status, priceRange));
            System.out.println("\nArtist registered successfully.\n");
        } 
        else if (name.contentEquals("0"))
        	System.out.println("\nYou have back to the HOME PAGE\n");
        else
            System.out.println("\nArtist already registered.\n");
    }

    @Override
    public void removeInfo() {
        System.out.println("\t\tArtist Deletion");
        System.out.println("_____________________________________________");
        Scanner input = new Scanner(System.in);

        System.out.println("Enter '0' to back to the HOME PAGE");
        System.out.print("Enter Artist name to be remove: ");
        String name = input.nextLine();
        if(name.equals("0"))
        	System.out.println("\nYou have back to the HOME PAGE\n");
        else {
        int oriSize = artists.size();
        for (int i = 0; i < artists.size(); i++) {
            if (name.equalsIgnoreCase(artists.get(i).getName())) {
                artists.remove(i);
                System.out.println("Artist removed from record successfully.");
                i = artists.size();
            }
        }
        if(oriSize == artists.size())
        {
        	System.out.println("\nArtist not Found! Please try again...\n");
        }}
    }

    @Override
    public void modifyInfo() {
    	int numArtist = artists.size();
    	boolean exit =false; //exit turn true when user wants to back to HOME PAGE
        Scanner input = new Scanner(System.in);
        do {
        	
        
        System.out.println("\t\tArtist Information Update");
        System.out.println("_____________________________________________");

    

        System.out.println("Enter '0' to back to the HOME PAGE");
        System.out.print("Enter Artist name to be modified: ");
        String name = input.nextLine();
        
    	if(name.equals("0"))
		{
			exit = true;
			System.out.println("\nYou are back to the HOME PAGE\n");
			break;
			
		}
        
       
        for (int i = 0; i < artists.size(); i++) // find the artist info that the user wants to modify
        {
            if (name.equalsIgnoreCase(artists.get(i).getName())) 
            {
            	numArtist = i;
            }
        }
        if(numArtist == artists.size()) //if the artist not found
		{
			System.out.println("Artist Not Found !\n");
		}
        }while(numArtist == artists.size());
        
        String answer;
        while(!exit){
		System.out.println("\nWhat information do you want to modify?");
		System.out.println("1. Name");
		System.out.println("2. Age");
		System.out.println("3. Specialty");
		System.out.println("4. Status (Alive/Deceased)");
		System.out.println("5. Price Range");
		
		int choice = input.nextInt();
		switch (choice)
        {
		case 1 :
			String confirm;
			String changedName;
			
			input.nextLine();//avoid bug
			do {
			boolean exist = false;
			System.out.println("Please enter the name:");
			changedName = input.nextLine();
			for (int i = 0; i < artists.size(); i++) {
		            if (changedName.equalsIgnoreCase(artists.get(i).getName())) {
		                exist = true;
		            }
		        }
			if(!exist)
			{
			System.out.println("Please confirm that the name entered is :" + changedName.toUpperCase());//let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the name...");
			confirm = input.next();
			if(confirm.equals("0"))
				input.nextLine();
			}
			else
			{
				System.out.println("Artist is already exist! Please try again...\n");
				confirm = "0";
			}
			}while(confirm.equals("0"));
			artists.get(numArtist).setName(changedName);
			break;
		case 2:
			boolean loop;
			int changedAge;
			String confirm1;
			do {
				loop = false;
			input.nextLine();//avoid bug
		try {
			do {	
			System.out.println("Please enter the age:");
			changedAge = input.nextInt();
			System.out.println("Please confirm that the age entered is :" + changedAge);//let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the age...");
			confirm1 = input.next();
			if(confirm1.equals("0"))
				input.nextLine();
			else if(changedAge < 0)
			{
				loop = true;
				System.out.println("Age should be greater than 0.\n");
			}
			}while(confirm1.contentEquals("0"));
				artists.get(numArtist).setAge(changedAge);
			}catch(InputMismatchException ex)
			{
				System.out.println("Invalid input! Please try again...\n");
				loop = true;
			}
			}while(loop);
			
			
			break;
		case 3:
			String changedSpecialty;
			String confirm2;
			do {
			input.nextLine();//avoid bug
			System.out.println("Please enter the new specialty:");
			changedSpecialty = input.nextLine();
			System.out.println("Please confirm that the new specialty entered is :" + changedSpecialty); //let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the specialty...");
			confirm2 = input.next();
			}while(confirm2.contentEquals("0"));
			artists.get(numArtist).setSpecialty(changedSpecialty);
			break;
		case 4:
			String changedStatus;
			String confirm3;
			do {
			input.nextLine();//avoid bug
			do {
			System.out.println("Please enter the status (Alive/Deceased):");
			changedStatus = input.nextLine();
			if(!changedStatus.equalsIgnoreCase("Alive")&& !changedStatus.equalsIgnoreCase("Deceased"))
				System.out.println("\nArtist Status should be <ALIVE> or <DECEASED> only.\n");
			}while(!changedStatus.equalsIgnoreCase("Alive")&& !changedStatus.equalsIgnoreCase("Deceased"));
			System.out.println("Please confirm that the new status entered is :" + changedStatus); //let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the status...");
			confirm3 = input.next();
			}while(confirm3.contentEquals("0"));
			artists.get(numArtist).setStatus(changedStatus);
			break;
		case 5:
			boolean validRange = false;
            String priceRange = "0";
            double min = -1;
            double max = -1;
          
            input.nextLine();//avoid bug
            do {
                try {
                     System.out.print("Enter Artwork Minimum Price: ");
                     min = Double.parseDouble(input.nextLine());
                     System.out.print("Enter Artwork Maximum Price: ");
                     max = Double.parseDouble(input.nextLine());
                     priceRange = min + "-" + max;
                     if(min < 0 || max < 0 || max < min)
                     {
                    	System.out.println("Price should be greater than '0' and maximum price should be greater than minimum price.\n");
                     }
                     else
                      	validRange = true;
                     } catch (Exception ex) {
                        System.out.println("INVALID INPUT.");
                    }
            } while (!validRange);

            artists.get(numArtist).setPriceRange(priceRange);
        default :
            System.out.println("Invalid input! Please try again...");
		}
		boolean yesNoExit = false;
        System.out.println("Modified successfully !");
        while (!yesNoExit) {
                
            System.out.println("Do you wish to perform any action? (y/n)"); //ask the user whether to continue or back to the HOME PAGE
            answer = input.next();
            if(answer.equalsIgnoreCase("n"))
            {
                yesNoExit = true;
                exit = true;
                System.out.println("\nYou are back to the HOME\n");
            }
            else if(answer.equalsIgnoreCase("y"))
            {
                yesNoExit = true;
            }
            else {
                System.out.println("Invalid input! Please try again...");
            }
        }
	}
  }
}