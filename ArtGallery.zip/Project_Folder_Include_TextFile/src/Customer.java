import java.util.ArrayList;

public class Customer extends Person{
    
    private String contactNum, artistPreference;
    private ArrayList <String> artworkPurchases;

    public String getContactNum()
    {
        return contactNum;
    }

    public void setContactNum(String contactNum)
    {
        this.contactNum = contactNum;
    }

    public String getArtistPreference()
    {
        return artistPreference;
    }

    public void setArtistPreference(String artistPreference)
    {
        this.artistPreference = artistPreference;
    }

    public ArrayList <String> getArtworkPurchase()
    {
        return artworkPurchases;
    }

    public void setArtworkPurchase(ArrayList<String> artworkPurchases)
    {
        this.artworkPurchases = artworkPurchases;
    }

    public Customer(String name, int age, String contactNum, String artistPreference, ArrayList<String> artworkPurchases)
    {
        super(name, age);
        this.contactNum = contactNum;
        this.artistPreference = artistPreference;
       this.artworkPurchases = artworkPurchases;
    }

}