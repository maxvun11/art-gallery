import java.util.*;
import java.util.zip.Inflater;
import java.io.File;
import java.io.PrintWriter;

public class ArtworkPurchaseMenu extends AdminMenu {

    private ArrayList<Artwork> artworks = new ArrayList<Artwork>();
    private ArrayList<Artist> artists = new ArrayList<Artist>();
    
    public void readArtwork() {
        try {
            Scanner infile = new Scanner(new File("Artwork.txt"));

            while (infile.hasNextLine()) {
                String title = infile.nextLine();
                String datePurchased = infile.nextLine();
                String dateSold = infile.nextLine();
                double purchasePrice =Double.parseDouble(infile.nextLine());

                String name = infile.nextLine();
                int age = Integer.parseInt(infile.nextLine());
                String specialty = infile.nextLine();
                String status = infile.nextLine();
                String priceRange = infile.nextLine();
                Artist artist = new Artist(name, age, specialty, status, priceRange);

                boolean isSold = Boolean.parseBoolean(infile.nextLine());
                double sellingPrice = Double.parseDouble(infile.nextLine());

                artworks.add(new Artwork(title, datePurchased,purchasePrice, dateSold, artist, isSold,sellingPrice));
            }
            infile.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public void updateArtwork() {
        try {
            PrintWriter outfile = new PrintWriter("Artwork.txt");

            for (Artwork artwork : artworks) {
                outfile.println(artwork.getTitle().toUpperCase() + "\n" +
                artwork.getDatePurchased().toUpperCase() + "\n" + 
                artwork.getDateSold().toUpperCase() + "\n" +Double.toString(artwork.getPurchasePrice())+ "\n"+
                artwork.getArtist().getName().toUpperCase() + "\n" + artwork.getArtist().getAge() + "\n"
                        + artwork.getArtist().getSpecialty().toUpperCase() + "\n" + artwork.getArtist().getStatus().toUpperCase() + "\n"
                        + artwork.getArtist().getPriceRange() + "\n" + artwork.getIsSold()+ "\n" + Double.toString(artwork.getPurchasePrice()));
            }
            outfile.close();

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
    
    public void readArtist() {
        try {
            Scanner infile = new Scanner(new File("Artist.txt"));

            while (infile.hasNextLine()) {
                String name = infile.nextLine();
                int age = Integer.parseInt(infile.nextLine());
                String specialty = infile.nextLine();
                String status = infile.nextLine();
                String priceRange = infile.nextLine();
                artists.add(new Artist(name, age, specialty, status, priceRange));
            }
            infile.close();
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @Override
    public void viewInfo() {
    	boolean exit = false;
    	do {
    	try {
    	Scanner input = new Scanner(System.in);
        System.out.println("\t\tArtwork List");
        System.out.println("_____________________________________________\n");
        System.out.println("How you wants to view the artwork list?");
        System.out.println("1. View All Artwork List");
        System.out.println("2. View Artwork List By Categories");
        System.out.println("(Enter '0' to return to the HOME PAGE)");
        int choice = input.nextInt();
        String artist;
        if(choice == 1)
        {
        	 for (int i = 0; i < artworks.size(); i++) {
                 System.out.println("\nArtwork " + (i + 1));
                 System.out.println("_____________________");
                 System.out.println("Title: " + artworks.get(i).getTitle());
                 System.out.println("Artist: " + artworks.get(i).getArtist().getName());
                 System.out.println("Purchasing Date: " + artworks.get(i).getDatePurchased());
                 System.out.println("Purchase Price: "+ artworks.get(i).getPurchasePrice());
                 if (artworks.get(i).getIsSold()) {
                     System.out.println("Status: Sold");
                     System.out.println("Sold Date: " + artworks.get(i).getDateSold());
                     System.out.println("Selling Price: " + artworks.get(i).getSellingPrice());
                 }
                 else
                     System.out.println("Status: Unsold");
             }
        	 System.out.println();
        	 exit = true;
        }
        else if (choice == 2)
        {
        	boolean exit2 = false;
        	do {
        		try {
        	
        	System.out.println("\nWhat is the category you wish to search for?");
        	System.out.println("1. Artist");
        	System.out.println("2. Status of being sold");
        	int category = input.nextInt();
        	if(category == 1)
        	{
        		input.nextLine();
        		System.out.println("Enter the artist name :");
            	artist = input.nextLine();
            	int count =0;
            	for(int i =0; i < artworks.size();i ++)
            	{
            		if(artist.equalsIgnoreCase(artworks.get(i).getArtist().getName()))
            				{ System.out.println("\nArtwork " + (i + 1));
                            System.out.println("_____________________");
                            System.out.println("Title: " + artworks.get(i).getTitle());
                            System.out.println("Artist: " + artworks.get(i).getArtist().getName());
                            System.out.println("Purchasing Date: " + artworks.get(i).getDatePurchased());
                            System.out.println("Purchase Price: "+ artworks.get(i).getPurchasePrice());
                            if (artworks.get(i).getIsSold()) {
                                System.out.println("Status: Sold");
                                System.out.println("Sold Date: " + artworks.get(i).getDateSold());
                                System.out.println("Selling Price: "+ artworks.get(i).getSellingPrice());
                                exit2 = true;
                    			exit = true;
                            }
                            else
                            {
                            	System.out.println("Status: Unsold");
                            	exit2 = true;
                      			exit = true;
                            }
                                
                       	 System.out.println();
            				}
            		else 
            			count++;
            			
            	}
            	if(count == artworks.size())
            		System.out.println("Artist is not found! Please try again...\n");
            	else
            		exit = true;
            	
            }
        	else if (category == 2)
        	{
        		boolean exit1 = false;
        		do{
        			System.out.println("Sold / Unsold");
        		String isSold = input.next();
        		if (isSold.equalsIgnoreCase("Sold"))
    			{
        			for(int i =0; i < artworks.size(); i ++)
            		{
            			if(artworks.get(i).getIsSold())
            			{
            				System.out.println("\nArtwork " + (i + 1));
                            System.out.println("_____________________");
                            System.out.println("Title: " + artworks.get(i).getTitle());
                            System.out.println("Artist: " + artworks.get(i).getArtist().getName());
                            System.out.println("Purchasing Date: " + artworks.get(i).getDatePurchased());
                            System.out.println("Purchase Price: " + artworks.get(i).getPurchasePrice());
                            System.out.println("Status: Sold");
                            System.out.println("Sold Date: " + artworks.get(i).getDateSold());
                            System.out.println("Selling Price: "+ artworks.get(i).getSellingPrice());
                            System.out.println();
            			}
            			
            		}
        			exit1 = true;
        			exit2 = true;
        			exit = true;
    			}
        		else if (isSold.equalsIgnoreCase("Unsold"))
        		{
        			for(int i =0; i < artworks.size(); i ++)
            		{
            			if(!artworks.get(i).getIsSold())
            			{
            				System.out.println("\nArtwork " + (i + 1));
                            System.out.println("_____________________");
                            System.out.println("Title: " + artworks.get(i).getTitle());
                            System.out.println("Artist: " + artworks.get(i).getArtist().getName());
                            System.out.println("Purchasing Date: " + artworks.get(i).getDatePurchased());
                            System.out.println("Purchase Price: "+ artworks.get(i).getPurchasePrice());
                            System.out.println("Status: Unsold");
                            System.out.println();
            			}
            		}
        			exit1 = true;
        			exit2 = true;
        			exit = true;
        		}
        		else
        			System.out.println("Please just enter 'sold' or 'unsold'...\n");
        		}while(!exit1);
        		
        	}
        	else
        		System.out.println("Only '1' and '2' are allowed to input! Please try again...");
        	}catch(InputMismatchException ex)
            	{
            		System.out.println("Invalid input!\n");
            		exit2 = false;
            		input.nextLine(); //avoid bug
            }	
        	}while(!exit2);
           
        	
        	}
        else if (choice == 0)
        	exit = true;
        else
        {
        	System.out.println("Only '1' and '2' are allowed to input! Please try again...\n");
        }
    	}catch(InputMismatchException ex)
    	{
    		System.out.println("Invalid input!\n");
    		exit = false;
    	}	
    	}while(!exit);
        	
    			
    }

    @Override
    public void addInfo() {
        System.out.println("\t\tArtwork Registration");
        System.out.println("_____________________________________________");
        Scanner input = new Scanner(System.in);

        boolean exist = false;

        System.out.println("Enter '0' to back to the HOME PAGE");
        System.out.print("Enter Artwork Title: ");
        String title = input.nextLine();

        if(title.contentEquals("0"))
        	exist = true;
        
        for (int i = 0; i < artworks.size(); i++) {
            if (title.equalsIgnoreCase(artworks.get(i).getTitle())) {
                exist = true;
            }
        }

        if (!exist) {
            String status;
            do {
                System.out.print("Enter Artwork Status (Sold/Unsold): ");
                status = input.nextLine();
                if (!status.equalsIgnoreCase("SOLD") && !status.equalsIgnoreCase("UNSOLD"))
                    System.out.println("Invalid Data Entered.");
            } while (!status.equalsIgnoreCase("SOLD") && !status.equalsIgnoreCase("UNSOLD"));
            boolean isSold;
            double sellingPrice = 0.0;
            if (status.equalsIgnoreCase("SOLD"))
            {
            	 isSold = true;
            	 System.out.println("What is the selling price?: ");
            	 sellingPrice = input.nextDouble();
            }
               
            else
            {
            	isSold = false;
            	System.out.println("Press enter to continue...");
            }
                

            boolean validDate = false;
            String datePurchased = "INVALID";
            String dateSold = "INVALID";
            int pYear = 0;
            int pMonth = 0;
            int pDay = 0;
            int sYear = 0;
            int sMonth = 0;
            int sDay = 0;           
            double purchasePrice = 0.0;
            do {
                try {

                	input.nextLine();//avoid bug
                    System.out.print("Enter Purchasing Year: ");
                    pYear = Integer.parseInt(input.nextLine());
        
                    System.out.print("Enter Purchasing Month: ");
                    pMonth = Integer.parseInt(input.nextLine());            
                    
                    System.out.print("Enter Purchasing Day: ");
                    pDay = Integer.parseInt(input.nextLine());
                    validDate = true;

                    System.out.println("Enter Purchase Price: ");
                    purchasePrice = input.nextDouble();
                    
                    if (isSold) {
                        validDate = false;
            
                        input.nextLine(); //avoid bug 
                        System.out.print("Enter Sold Year: ");
                        sYear = Integer.parseInt(input.nextLine());
            
                        System.out.print("Enter Sold Month: ");
                        sMonth = Integer.parseInt(input.nextLine());          
                        
                        System.out.print("Enter Sold Day: ");
                        sDay = Integer.parseInt(input.nextLine());
            
                        if(pYear != sYear)
                        {
                        	if(pYear > sYear)
                        		System.out.println("Invalid Date Entered.");
                        	else
                        	{
                        		validDate = true;
                                datePurchased = pDay + "/" + pMonth + "/" + pYear;
                                dateSold = sDay + "/" + sMonth + "/" + sYear;
                        	}
                        }
                        else
                        {
                        	if(pMonth != sMonth)
                        	{
                        		if(pMonth > sMonth)
                        			System.out.println("Invalid Date Entered.");
                        		else
                        		{
                        			validDate = true;
                                    datePurchased = pDay + "/" + pMonth + "/" + pYear;
                                    dateSold = sDay + "/" + sMonth + "/" + sYear;
                        		}
                        			
                        	}
                        	if(pMonth == sMonth)
                        	{
                        		if(pDay > sDay)
                        			System.out.println("Invalid Date Entered.");
                        		else
                        		{
                        			validDate = true;
                                    datePurchased = pDay + "/" + pMonth + "/" + pYear;
                                    dateSold = sDay + "/" + sMonth + "/" + sYear;
                        		}
                        			
                        	}
                        }
                    }
                    else
                    {
                    	validDate = true;
                        datePurchased = pDay + "/" + pMonth + "/" + pYear;
                    }
                }catch (Exception ex) {
                    System.out.println("Invalid Date Entered");
                }
            } while (!validDate);

            Artist artist = inputArtist();


            artworks.add(new Artwork(title, datePurchased, purchasePrice, dateSold, artist, isSold, sellingPrice));
            System.out.println("\nArtwork registered successfully.\n");
        } 
        else if (title.contentEquals("0"))
        	System.out.println("\nYou have back to the HOME PAGE\n");
        else
            System.out.println("Artwork already registered.\n");
    }

    @Override
    public void removeInfo() {
        System.out.println("\t\tArtwork Deletion");
        System.out.println("_____________________________________________");
        Scanner input = new Scanner(System.in);

        System.out.println("Enter '0' to back to the HOME PAGE");
        System.out.print("Enter artwork name to be remove: ");
        String title = input.nextLine();
        
        if(title.equals("0"))
        	System.out.println("\nYou have back to the HOME PAGE\n");
        else {
        int oriSize = artworks.size();
        for (int i = 0; i < artworks.size(); i++) {
            if (title.equalsIgnoreCase(artworks.get(i).getTitle())) {
                artworks.remove(i);
                System.out.println("Artwork removed from record successfully.");
                i = artworks.size();
            }
        }
        if(oriSize == artworks.size())
        {
        	System.out.println("\nArtwork not Found! Please try again...\n");
        }
        }
    }

    @Override
    public void modifyInfo() {
    	int numArtwork = artworks.size();
    	boolean exit = false; //exit turn true when user wants to back to HOME PAGE
    	 Scanner input = new Scanner(System.in);
    	 do {
        System.out.println("\t\tArtwork Information Update");
        System.out.println("_____________________________________________");

       

        System.out.println("Enter '0' to back to the HOME PAGE");
        System.out.print("Enter Artwork Title: ");
        String title = input.nextLine();
        
        if(title.equals("0"))
		{
			exit = true;
			System.out.println("\nYou are back to the HOME PAGE\n");
			break;
			
		}

        for (int i = 0; i < artworks.size(); i++) // find the artwork info that the user wants to modify
        {
            if (title.equalsIgnoreCase(artworks.get(i).getTitle())) 
            {
            	numArtwork = i;
            }
        }
    	if(numArtwork == artworks.size()) //if the artwork not found
		{
			System.out.println("Artwork Not Found !\n"); 
		}
		}while(numArtwork == artworks.size());
    	 
    	 	
    		String answer;
    		while(!exit)
			{

				boolean loop = false; //loop turn true after catch InputMismatchException or invalid input for the choice
				do {
					try {

						System.out.println("\nWhat information do you want to modify?");
						System.out.println("1. Title");
						System.out.println("2. Status");
						System.out.println("3. Purchase Price");
						System.out.println("4. Purchase Date");
						System.out.println("5. Artist");

						int choice = input.nextInt();
						switch (choice) {
							case 1:
								String confirm;
								String changedTitle;
								input.nextLine();//avoid bug
								do {
									boolean exist = false;
									System.out.println("Please enter the title:");
									changedTitle = input.nextLine();
									for (int i = 0; i < artworks.size(); i++) {
										if (changedTitle.equalsIgnoreCase(artworks.get(i).getTitle())) {
											exist = true;
										}
									}
									if (!exist) {
										System.out.println("Please confirm that the title entered is :"
												+ changedTitle.toUpperCase());
										System.out.println("Press any key other than '0' to continue...");
										System.out.println("Press 0 to re-enter the title...");
										confirm = input.next();
										if (confirm.equals("0"))
											input.nextLine();
									} else {
										System.out.println("Artwork is already exist! Please try again...\n");
										confirm = "0";
									}
								} while (confirm.equals("0"));
								artworks.get(numArtwork).setTitle(changedTitle);
								
								break;
							case 2:
								String dateSold = null;
								String status;

								input.nextLine();//avoid bug
								if (!artworks.get(numArtwork).getIsSold()) {

									do {
										System.out.print("Enter Artwork Status: ");
										status = input.nextLine();
										if (!status.equalsIgnoreCase("SOLD"))
											System.out.println("Artwork status can only change from UNSOLD to SOLD");
									} while (!status.equalsIgnoreCase("SOLD"));
									double sellingPrice = 0.0;
									boolean exit1 = false; // determine whether the input (date of sold) valid or not
									boolean exit2; // determine whether the input (selling price) valid or not

									do {
										try {
											do {
												exit2 = true;
												System.out.println("What is the selling price?: ");

												sellingPrice = input.nextDouble();
												if (sellingPrice <= 0) {
													System.out.println("Price should be greater than zero!");
													exit2 = false;
												}

											} while (!exit2);

											input.nextLine();//avoid bug
											System.out.print("Enter Sold Year: ");
											int sYear = Integer.parseInt(input.nextLine());

											System.out.print("Enter Sold Month: ");
											int sMonth = Integer.parseInt(input.nextLine());

											System.out.print("Enter Sold Day: ");
											int sDay = Integer.parseInt(input.nextLine());

											if (sDay < 0 || sMonth < 0 || sYear < 0) {
												exit1 = false;
												System.out.println(
														"\nInvalid input\nPress Enter to re-enter the information for the sold status...");
											} else {
												exit1 = true;
												dateSold = sDay + "/" + sMonth + "/" + sYear;
												System.out.println("Press enter to continue...");
											}

										} catch (InputMismatchException ex) {
											System.out.println("Invalid Input");

										} catch (NumberFormatException ex) {
											System.out.println(
													"Invalid input\nPress Enter to re-enter the information for the sold status...");

										}
										input.nextLine();// avoid bug
									} while (!exit1);
									artworks.get(numArtwork).setDateSold(dateSold);
									artworks.get(numArtwork).setSellingPrice(sellingPrice);
									artworks.get(numArtwork).setIsSold(true);
									
								} else {
									System.out.println("Artwork status can only change from UNSOLD to SOLD");
								}

								break;

							case 3:
								double changedPPrice = 0;
								String confirm1;

								input.nextLine();//avoid bug
								do {

									try {

										System.out.println("Please enter the purchase price:");
										changedPPrice = input.nextDouble();

									} catch (InputMismatchException ex) {
										System.out.println("Invalid input! System can't record the price");
										input.nextLine();
									}

									System.out.println(
											"Please confirm that the purchase price entered is :" + changedPPrice);
									System.out.println("Press any key other than '0' to continue...");
									System.out.println("Press 0 to re-enter the purchase price...");
									confirm1 = input.next();
									if (confirm1.equals("0"))
										input.nextLine();
								} while (confirm1.contentEquals("0"));

								artworks.get(numArtwork).setPurchasePrice(changedPPrice);
								

								break;
							case 4:
								String changedPurchaseDate = null;
								int day, month, year;
								boolean loop1 = false; //determine whether the input (date of purchased) valid or not
								String confirm2;
								do {
									input.nextLine();//avoid bug
									try {
										do {
											loop1 = false;
											System.out.print("Enter Purchasing Year: ");
											year = Integer.parseInt(input.nextLine());

											System.out.print("Enter Purchasing Month: ");
											month = Integer.parseInt(input.nextLine());

											System.out.print("Enter Purchasing Day: ");
											day = Integer.parseInt(input.nextLine());
											if (year < 0 || month < 0 || day < 0) {
												confirm2 = "0";
												System.out.println("\nInvalid input. Please try again...\n");
											}

											else {
												changedPurchaseDate = day + "/" + month + "/" + year;
												System.out.println("Please confirm that the contact number entered is :"
														+ changedPurchaseDate);
												System.out.println("Press any key other than '0' to continue...");
												System.out.println("Press 0 to re-enter the contact...");
												confirm2 = input.next();
												if (confirm2.equals("0"))
													input.nextLine();
											}
										} while (confirm2.contentEquals("0"));
										artworks.get(numArtwork).setDatePurchased(changedPurchaseDate);
									} catch (NumberFormatException ex) {
										System.out.println("Invalid input! Press enter to try again...\n");
										loop1 = true;

									}
								} while (loop1);
								

								break;

							case 5:
								Artist artist = inputArtist();
								artworks.get(numArtwork).setArtist(artist);
								
								break;
							default:
								System.out.println("Invalid input! Please try again...\n");
								loop = true;
						}
					} catch (InputMismatchException ex) {
						System.out.println("Invalid input! Please try again...\n");
						loop = true;
						input.nextLine();//avoid bug
					}
				} while (loop);

				boolean yesNoExit = false;
				System.out.println("Modified successfully !");
				while (!yesNoExit) {

					System.out.println("Do you wish to perform any action? (y/n)"); //ask the user whether to continue or back to the HOME PAGE
					answer = input.next();
					if (answer.equalsIgnoreCase("n")) {
						yesNoExit = true;
						exit = true;
						System.out.println("\nYou are back to the HOME\n");
					} else if (answer.equalsIgnoreCase("y")) {
						yesNoExit = true;
					} else {
						System.out.println("Invalid input! Please try again...");
					}
				}
			}
   }

        
    public Artist inputArtist()
    {
    	Scanner input = new Scanner(System.in);
    	int count;
    	String name;
    	boolean loop;
    	do {
    	count = 0;
    	loop = false;
    	
    	System.out.print("Enter Artist Name: ");
    	while (!input.hasNext("[A-Za-z]+"))  // to check whether the name is alphabetical letter or not
    	{ 
    	        System.out.println("Invalid input! Please try again...\n");
    	        System.out.print("Enter Artist Name: ");
    	        input.next();
    	}
    	name = input.nextLine();
    	

    	for (int i = 0; i < artists.size(); i++) {
    	    if (name.equalsIgnoreCase(artists.get(i).getName())) {
    	        break;
    	    } else {
    	        count++;
    	    }
    	}
    	
    	if (count == artists.size()) {
    	    System.out.println("Artist not found! Please try again...\n");
    	    System.out.println("Press enter to continue...\n");
    	    loop = true;
    	    input.nextLine(); //avoid bug
    	}
    	
    	}while(loop);
    	return artists.get(count);
    }
}