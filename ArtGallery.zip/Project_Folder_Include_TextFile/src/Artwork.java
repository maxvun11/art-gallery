public class Artwork {
    
    private String title, datePurchased, dateSold;
    private double sellingPrice, purchasePrice;
    private Artist artist;
    private boolean isSold;

    
    public double getSellingPrice()
    {
    	return sellingPrice;
    }
    
    public void setSellingPrice(double sellingPrice)
    {
    	this.sellingPrice = sellingPrice;
    }
    
    public void setPurchasePrice(double purchasePrice)
    {
    	this.purchasePrice = purchasePrice;
    }
    public double getPurchasePrice()
    {
    	return purchasePrice;
    }
    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getDatePurchased()
    {
        return datePurchased;
    }

    public void setDatePurchased(String datePurchased)
    {
        this.datePurchased = datePurchased;
    }

    public String getDateSold()
    {
        return dateSold;
    }

    public void setDateSold(String dateSold)
    {
        this.dateSold = dateSold;
    }

    public Artist getArtist()
    {
        return artist;
    }

    public void setArtist(Artist artist)
    {
        this.artist = artist;
    }

    public boolean getIsSold()
    {
        return isSold;
    }

    public void setIsSold(boolean isSold)
    {
        this.isSold = isSold;
    }

    public Artwork(String title, String datePurchased,double purchasePrice, String dateSold, Artist artist, boolean isSold, double sellingPrice)
    {
        this.title = title;
        this.datePurchased = datePurchased;
        this.purchasePrice =purchasePrice;
        this.dateSold = dateSold;
        this.artist = artist;
        this.isSold = isSold;
        this.sellingPrice = sellingPrice;
    }

}
