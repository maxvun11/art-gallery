import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class App {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);

        System.out.println("\t\t__________________________________________");
        System.out.println("\t\t|                                        |");
        System.out.println("\t\t|                                        |");
        System.out.println("\t\t|      UX Gallery Management System      |");
        System.out.println("\t\t|                                        |");
        System.out.println("\t\t|________________________________________|");

        loginAccount();
        while (true) {
        	System.out.println("\t\tHome");
            System.out.println("_____________________________________________");
            System.out.println("1. Customer Menu\n2. Artist Menu\n3. Artwork Menu\n4. Reset Account\n5. Logout");
            System.out.print("Enter option: ");
            String option = input.nextLine();
            if (option.equals("1")) {
                CustomerMenu customerMenu = new CustomerMenu();
                customerMenu.readCustomer();
                System.out.println("\n\t\tCustomer Menu");
                System.out.println("_____________________________________________");
                System.out.println("1. View Customer\n2. Add Customer\n3. Modify Customer\n4. Remove Customer\n5. Back to home");
                openMenu(customerMenu);
                customerMenu.updateCustomer();
            }
            else if (option.equals("2")){
                ArtistMenu artistMenu = new ArtistMenu();
                artistMenu.readArtist();
                System.out.println("\n\t\tArtist Menu");
                System.out.println("_____________________________________________");
                System.out.println("1. View Artist\n2. Add Artist\n3. Modify Artist\n4. Remove Artist\n5. Back to home");
                openMenu(artistMenu);
                artistMenu.updateArtist();
            }
            else if (option.equals("3")){
                ArtworkPurchaseMenu artworkMenu = new ArtworkPurchaseMenu();
                artworkMenu.readArtwork();
                artworkMenu.readArtist();
                System.out.println("\n\t\tArtwork Purchase Menu");
                System.out.println("_____________________________________________");
                System.out.println("1. View Artwork\n2. Add Artwork\n3. Modify Artwork\n4. Remove Artwork\n5. Back to home");
                openMenu(artworkMenu);
                artworkMenu.updateArtwork();
            }
            else if (option.equals("4")){
            	System.out.println("\n\t\tReset Account");
                System.out.println("_____________________________________________");
                resetAccount();
            }
            else if (option.equals("5")){
                break;
            }
            else {
                System.out.println("Invalid Option.\n");
            }
        }
    }



    public static void loginAccount() 
    {
        File file = new File("OwnerAccount.txt");
        try {
            Scanner infile = new Scanner(file);
            String name = infile.nextLine();
            String password = infile.nextLine();
            Scanner input = new Scanner(System.in);
            while (true) {
                System.out.print("Enter username: ");
                String username = input.nextLine();
                System.out.print("Enter Password: ");
                String loginPassword = input.nextLine();
                if (username.equals(name) && loginPassword.equals(password)) {
                    System.out.println("\nLogin successfully\n");
                    break;
                } else
                    System.out.println("Incorrect username or password! Please try again...\n");
            }
        } 
        catch (Exception e) {
            System.out.println("You have not register account.");
            registerAccount();
        }
    }

    public static void registerAccount()
    {
    	File file = new File("OwnerAccount.txt");
        try {
            PrintWriter outfile = new PrintWriter(file);
    	    Scanner input = new Scanner(System.in);
            System.out.print("Enter new username: ");
            String username = input.nextLine();
            System.out.print("Enter new password: ");
            String loginPassword = input.nextLine();
    	    outfile.println(username + "\n" + loginPassword);
            outfile.close();
		}
        catch (FileNotFoundException e) {
            System.out.println("File not found!");
            ;
        }
        catch (Exception e) {
			System.out.println("An error has occured!");;
		}
        System.out.println("\nAccount created successfully\n");
    }
    public static void resetAccount()
    {
        File file = new File("OwnerAccount.txt");
        try {
            Scanner sc = new Scanner(file);
            String oldUserName = sc.nextLine();
            String oldPassword = sc.nextLine();
            Scanner input = new Scanner(System.in);
            while (true) {
                System.out.print("Enter old password: ");
                String oldPasswordTest = input.nextLine();
                if(oldPasswordTest.equals(oldPassword))
                {
                    PrintWriter outfile = new PrintWriter(file);
                    System.out.print("Enter new username: ");
                    String username = input.nextLine();
                    System.out.print("Enter new password: ");
                    String loginPassword = input.nextLine();
                    outfile.println(username + "\n" + loginPassword);
                    outfile.close();
                    System.out.println("\nAccount reset successfully\n");
                    break;
                }
                else
                {
                    System.out.println("Old password is incorrect! Please try again...\n");
                }
            } 
        } 
        catch (FileNotFoundException e) {
    	    System.out.println("File not found!");
        }
        catch (Exception ex) {
            System.out.println("An error has occured");
        }
    }

    public static void openMenu(AdminMenu menu) throws Exception
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter choice: ");
        String choice = input.nextLine();
        if (choice.equals("1"))
        	menu.viewInfo();
        else if (choice.equals("2"))
            menu.addInfo();
        else if (choice.equals("3"))
            menu.modifyInfo();
        else if (choice.equals("4"))
            menu.removeInfo();
        else if (choice.equals("5"))
            System.out.println("Exit successfully\n");
        else
            System.out.println("Invalid Choice! Please try again...\n");

    }
}