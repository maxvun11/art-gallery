import java.util.*;
import java.io.File;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

public class CustomerMenu extends AdminMenu {

	private ArrayList<Customer> customers = new ArrayList<Customer>();
	private ArrayList<Artwork> artworks = new ArrayList<Artwork>();
	
	public void readCustomer() {
		try {
			Scanner infile = new Scanner(new File("Customer.txt"));

			while (infile.hasNextLine()) {
				String name = infile.nextLine();
				int age = Integer.parseInt(infile.nextLine());
				String contactNum = infile.nextLine();
				String artistPreference = infile.nextLine();
				String[] artworkPurchases = infile.nextLine().split(",");
				ArrayList <String> artworkPurchasesArray = new ArrayList <String> ();
				for (int i =0; i < artworkPurchases.length; i++)
					artworkPurchasesArray.add(artworkPurchases[i]);
				customers.add(new Customer(name, age, contactNum, artistPreference, artworkPurchasesArray));
			}
			infile.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	public void readArtwork() {
		try {

			Scanner infile = new Scanner(new File("Artwork.txt"));
			while (infile.hasNextLine()) {
				String title = infile.nextLine();
				String datePurchased = infile.nextLine();
				String dateSold = infile.nextLine();
				double purchasePrice =Double.parseDouble(infile.nextLine());

				String name = infile.nextLine();
				int age = Integer.parseInt(infile.nextLine());
				String specialty = infile.nextLine();
				String status = infile.nextLine();
				String priceRange = infile.nextLine();
				Artist artist = new Artist(name, age, specialty, status, priceRange);

				boolean isSold = Boolean.parseBoolean(infile.nextLine());
				double sellingPrice = Double.parseDouble(infile.nextLine());

				artworks.add(new Artwork(title, datePurchased,purchasePrice, dateSold, artist, isSold,sellingPrice));
        }
        infile.close();
    } catch (Exception ex) {
        System.out.println(ex);
    }}

	
	public void updateCustomer() {
		try {
			PrintWriter outfile = new PrintWriter("Customer.txt");

			for (Customer customer : customers) {
				outfile.println(customer.getName().toUpperCase() + "\n" + customer.getAge() + "\n"
						+ customer.getContactNum() + "\n" + customer.getArtistPreference().toUpperCase() + "\n"
						+ String.join(",", customer.getArtworkPurchase()).toUpperCase());
			}
			outfile.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	@Override
	public void viewInfo() {
		System.out.println("\t\tCustomer List");
		System.out.println("_____________________________________________\n");
		for (int i = 0; i < customers.size(); i++) {
			System.out.println("\nCustomer " + (i + 1));
			System.out.println("_____________________");
			System.out.println("Name: " + customers.get(i).getName());
			System.out.println("Age: " + customers.get(i).getAge());
			System.out.println("Contact Number: " + customers.get(i).getContactNum());
			System.out.println("Artist Preference: " + customers.get(i).getArtistPreference());
			System.out.print("Artwork Purchases: ");
			for (int j = 0; j < customers.get(i).getArtworkPurchase().size(); j++) {
				if (j != customers.get(i).getArtworkPurchase().size() - 1)
					System.out.print(customers.get(i).getArtworkPurchase().get(j) + ", ");
				else
					System.out.println(customers.get(i).getArtworkPurchase().get(j));

			}
			System.out.println();
		}
	}

	@Override
	public void addInfo() {
		System.out.println("\t\tCustomer Registration");
		System.out.println("_____________________________________________");
		Scanner input = new Scanner(System.in);
		boolean exit = false;
		boolean exist = false;

		System.out.println("Enter '0' to back to the HOME PAGE");
		System.out.print("Enter Customer Name: ");
		String name = input.nextLine();

		 if(name.equals("0"))
		 {
			 exit = true;
			 System.out.println("\nYou are back to the HOME PAGE\n");
		 }
	        	
		 
		for (int i = 0; i < customers.size(); i++) {
			if (name.equalsIgnoreCase(customers.get(i).getName())) {
				exist = true;
			}
		}

		if (!exist && !exit) {
			int age = 0;
			do {
				try {
					System.out.print("Enter Customer age: ");
					age = Integer.parseInt(input.nextLine());
				} catch (Exception ex) {
					System.out.println("Customer age must larger than 0 and must be an integer.");
				}
			} while (age <= 0);

			System.out.print("Enter Customer Contact Number: ");
			String contactNum = input.nextLine();

			System.out.print("Enter Customer Preferred Artist(Enter <NO> if no prefered artist): ");
			String artistPreference = input.nextLine();
			if (artistPreference.equalsIgnoreCase("NO"))
				artistPreference = "NO PREFERRED ARTIST";
			
			int num = 0;
			do {
				System.out.print("Enter number of artwork purchases: ");
				try{
					num = Integer.parseInt(input.nextLine());
				}
				catch(NumberFormatException ex)
				{
					System.out.println("Invalid input! Please try again...\n");
					num = -1;
				}
				if (num <= 0)
					System.out.print("Number of artwork purchases should not be less than 1.\nPlease re-enter the number.\n");
			} while (num <= 0);

			String[] artworkPurchases = new String[num];
			
			boolean loop;
			for (int j = 0; j < num; j++) 
			{
				do{
					int count = 0;
					loop = false;
					System.out.printf("Enter Artwork Purchase %d: ", j + 1);
					artworkPurchases[j] = input.nextLine();
					
				for(int i =0;i < artworks.size();i ++)// to check whether the artwork exist or not and whether being sold
				{
					if(artworkPurchases[j].equalsIgnoreCase(artworks.get(i).getTitle()))
					{
						if(artworks.get(i).getIsSold())
						{
							System.out.println("This artwork is sold! Please try again...\n");
							loop = true;
							break;
						}
						else
						{
							
							break;
						}
							
						
					}
					else
					{
						count ++;
					}
				}

					
	
				}while(loop);
			}	
			ArrayList <String> tempArray = new ArrayList <String> ();
			for (int a =0; a< artworkPurchases.length;a++)
				tempArray.add(artworkPurchases[a]);
			
			customers.add(new Customer(name, age, contactNum, artistPreference, tempArray));
			System.out.println("\nCustomer registered successfully.\n");

		} 
		else if (exist)
			System.out.println("\nCustomer already registered.\n");
	}

	@Override
	public void removeInfo() {
		System.out.println("\t\tCustomer Deletion");
		System.out.println("_____________________________________________");
		Scanner input = new Scanner(System.in);

		System.out.println("Enter '0' to back to the HOME PAGE");
		System.out.print("Enter customer name to be remove: ");
		String name = input.nextLine();
		if(name.equals("0"))
        	System.out.println("\nYou have back to the HOME PAGE\n");
		else {
		int oriSize = customers.size();
		for (int i = 0; i < customers.size(); i++) {
			if (name.equalsIgnoreCase(customers.get(i).getName())) {
				customers.remove(i);
				System.out.println("\nCustomer removed from record successfully.\n");
			}
		}
		if(oriSize == customers.size())
        {
        	System.out.println("\nCustomer not Found! Please try again...\n");
        }
		}
	}
	

	@Override
	public void modifyInfo() {
		boolean loop = false; //loop after catch InputMismatchException
		boolean loop1 = false; //loop after catch NumberFormatException
		int numCustomer = customers.size();
		boolean exit =false; //exit turn true when user wants to back to HOME PAGE
		Scanner input = new Scanner(System.in);
			do {
		
		System.out.println("\t\tCustomer Information Update");
		System.out.println("_____________________________________________");

	
		
		System.out.println("Enter '0' to back to the HOME PAGE");
		System.out.print("Enter customer name to be modified: ");
		String name = input.nextLine();
		
		if(name.equals("0"))
		{
			exit = true;
			System.out.println("\nYou have back to the HOME PAGE\n");
			break;
			
		}
		
		for (int i = 0; i < customers.size(); i++) // find the customer info that the user wants to modify
		{
			if (name.equalsIgnoreCase(customers.get(i).getName())) 
			{
				numCustomer = i;
			}
		}
		if(numCustomer == customers.size()) //if the customer not found
		{
			System.out.println("Customer Not Found !\n");
		}
		}while(numCustomer == customers.size());
		
		String answer;
		while(!exit){
			do {
		System.out.println("\nWhat information do you want to modify?");
		System.out.println("1. Name");
		System.out.println("2. Age");
		System.out.println("3. Contact");
		System.out.println("4. Artwork Purchases");
		System.out.println("5. Artist Preference");
		try {
		int choice = input.nextInt();
		
		switch (choice)
		{
		case 1 :
			String confirm;
			String changedName;
			input.nextLine();//avoid bug
			do {
				boolean exist = false;
				System.out.println("Please enter the name:");
				changedName = input.nextLine();
				for (int i = 0; i < customers.size(); i++) {
					if (changedName.equalsIgnoreCase(customers.get(i).getName())) {
						exist = true;
					}
				}
				if(!exist)
				{
				System.out.println("Please confirm that the name entered is :" + changedName.toUpperCase()); //let the user to re-confirm his/her input to reduce the chance of making mistake
				System.out.println("Press any key other than '0' to continue...");
				System.out.println("Press 0 to re-enter the name...");
				confirm = input.next();
				if(confirm.equals("0"))
					input.nextLine();
				}
				else
				{
					input.nextLine();
					System.out.println("Customer is already exist! Please try again...\n");
					confirm = "0";
				}
			}while(confirm.equals("0"));
			customers.get(numCustomer).setName(changedName);
			break;
		case 2:
			int age;
			String confirm3;
			boolean loop2 = false;
			input.nextLine();//avoid bug
			do {
			try {
			do {
			loop2 = false;
			System.out.println("Please enter the new age:");
			age = input.nextInt();
			System.out.println("Please confirm that the age entered is :" + age); //let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the age...");
			confirm3 = input.next();
			if(confirm3.equals("0"))
				input.nextLine();
			else if (age < 0)
			{
				loop2 = true;
				System.out.println("Age should be greater than 0.\n");
			}
			}while(confirm3.contentEquals("0"));
			customers.get(numCustomer).setAge(age);
			
			}catch(InputMismatchException ex)
			{
				System.out.println("Invalid input! Please try again...\n");
				loop2 = true;
				input.nextLine(); //avoid bug
				
			}
			}while(loop2);
			
			break;
		case 3:
			String changedContact;
			String confirm1;
			input.nextLine();//avoid bug
			do {
			System.out.println("Please enter the new contact:");
			changedContact = input.nextLine();
			System.out.println("Please confirm that the contact number entered is :" + changedContact); //let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the contact...");
			confirm1 = input.next();
			if(confirm1.equals("0"))
				input.nextLine();
			}while(confirm1.contentEquals("0"));
			customers.get(numCustomer).setContactNum(changedContact);
			break;
		case 4:
			input.nextLine();//avoid bug
			String artworkTitle;
			boolean exist;
			
			ArrayList <String> tempArray = new ArrayList <String>();
			tempArray = customers.get(numCustomer).getArtworkPurchase();
			
			do {
				int count =0;
				exist = true;
			
			System.out.println("Please enter the title of new artwork purchase:");
			artworkTitle = input.nextLine();
			for(int i =0;i < artworks.size();i ++) // to check whether the artwork exist or not and whether being sold
			{
				if(artworkTitle.equalsIgnoreCase(artworks.get(i).getTitle()))
				{
					if(artworks.get(i).getIsSold())
					{
						System.out.println("This artwork is sold! Please try again...\n");
						exist = false;
						break;
					}
					else
					{
						
						break;
					}
						
					
				}
				else
				{
					count ++;
				}
			}
			}while(!exist);
			tempArray.add(artworkTitle);
			customers.get(numCustomer).setArtworkPurchase(tempArray);
			break;
		case 5:
			String changedArtist;
			String confirm2;
			do {
			input.nextLine();//avoid bug
			System.out.println("Please enter the new artist preference:");
			changedArtist = input.nextLine();
			System.out.println("Please confirm that the new artist preference entered is :" + changedArtist);//let the user to re-confirm his/her input to reduce the chance of making mistake
			System.out.println("Press any key other than '0' to continue...");
			System.out.println("Press 0 to re-enter the artist preference...");
			confirm2 = input.next();
			}while(confirm2.contentEquals("0"));
			customers.get(numCustomer).setArtistPreference(changedArtist);
			break;
		default :
			System.out.println("Invalid input! Please try again...");
			loop = true;
		
	}
		}catch(InputMismatchException ex)
		{
			System.out.println("Invalid input! Please try again...\n");
			loop = true;
			input.nextLine();//avoid bug
		}
		
	} while (loop);
	
	boolean yesNoExit = false;
	System.out.println("Modified successfully !");
	while (!yesNoExit) {
			
		System.out.println("Do you wish to perform any action? (y/n)"); //ask the user whether to continue or back to the HOME PAGE
		answer = input.next();
		if(answer.equalsIgnoreCase("n"))
		{
			yesNoExit = true;
			exit = true;
			System.out.println("\nYou are back to the HOME\n");
		}
		else if(answer.equalsIgnoreCase("y"))
		{
			yesNoExit = true;
		}
		else {
			System.out.println("Invalid input! Please try again...");
		}
	}
		
			
	}
}
}
